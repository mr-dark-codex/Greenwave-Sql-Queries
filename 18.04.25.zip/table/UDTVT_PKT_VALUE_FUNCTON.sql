USE [ITC_CheckWeigher_2.0]
GO

/****** Object:  UserDefinedFunction [dbo].[UDTVT_CW_PKT_PARAMETER]    Script Date: 18-04-2025 16:38:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


ALTER FUNCTION [dbo].[UDTVT_CW_PKT_PARAMETER] (@givenDateAndTime DATETIME, @CW INT)
RETURNS TABLE
AS 
RETURN 
SELECT *
FROM
(
	SELECT dateandtime, parameterName, val , CWNO
	FROM
	(
		SELECT TOP(1) F.VAL, 
		SUBSTRING(T.TAGNAME, 0, CHARINDEX('\', T.tagName)) [CWNO],
		SUBSTRING(T.TagName, CHARINDEX('\', T.TagName) + 1, LEN(T.tagName)) [ParameterName], 
		F.DateAndTime
		From dbo.FloatTable_15min f, dbo.TagTable_15min t
		where t.TagIndex = f.tagindex
		and f.dateandtime BETWEEN DATEADD(MINUTE, -1440, @givenDateAndTime) AND  @givenDateAndTime
		and t.TagName LIKE CONCAT('%', @CW, '%HIGH_VALUE')
		ORDER BY F.DateAndTime DESC
	) AS HIGH_VALUE 
	union all
	SELECT dateandtime, parameterName, val , CWNO
	from
	(
		SELECT TOP(1) F.VAL,
		SUBSTRING(T.TAGNAME, 0, CHARINDEX('\', T.tagName)) [CWNO],
		SUBSTRING(T.TagName, CHARINDEX('\', T.TagName) + 1, LEN(T.tagName)) [ParameterName], 
		F.DateAndTime
		From dbo.FloatTable_15min f, dbo.TagTable_15min t
		where t.TagIndex = f.tagindex
		and f.dateandtime BETWEEN DATEADD(MINUTE, -1440, @givenDateAndTime) AND  @givenDateAndTime
		and t.TagName LIKE CONCAT('%', @CW, '%LOW_VALUE')
		ORDER BY F.DateAndTime DESC
	) AS LOW_VALUE
	union all
	SELECT dateandtime, parameterName, val , CWNO
	from
	(
		SELECT TOP(1) F.VAL, 
		SUBSTRING(T.TAGNAME, 0, CHARINDEX('\', T.tagName)) [CWNO],
		SUBSTRING(T.TagName, CHARINDEX('\', T.TagName) + 1, LEN(T.tagName)) [ParameterName], 
		F.DateAndTime
		From dbo.FloatTable_15min f, dbo.TagTable_15min t
		where t.TagIndex = f.tagindex
		and f.dateandtime BETWEEN DATEADD(MINUTE, -1440, @givenDateAndTime) AND  @givenDateAndTime
		and t.TagName LIKE CONCAT('%', @CW, '%TARGET_VALUE')
		ORDER BY F.DateAndTime DESC
	) AS TARGET_VALUE
) AS ALL_TABLE 
PIVOT (
	
	MAX(VAL) 
	FOR parameterName in (SKU_PKT_HIGH_VALUE, SKU_PKT_LOW_VALUE, SKU_PKT_target_VALUE)

) as PT
GO


