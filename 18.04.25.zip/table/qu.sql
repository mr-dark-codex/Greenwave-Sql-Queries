-- SELECT * 
-- FROM dbo.TagTable T, dbo.FloatTable_test F
-- WHERE T.TagIndex = F.TagIndex;


SELECT 
SUM(R.Val) [SUM], R.TagName, R.monthnum FROM
(SELECT T.TagName , F.Val, MONTH(f.DateAndTime) [monthnum],
COALESCE(
    LEAD(F.Val)  OVER( PARTITION BY T.TagName ORDER BY F.DateAndTime) - F.VAL, 0.0
) [VALPERMIN]
FROM dbo.FloatTable_test F, dbo.TagTable T
WHERE f.TagIndex = T.TagIndex 
AND T.TagName LIKE '%ENERGY'
AND MONTH(F.DateAndTime) = 12 AND YEAR(F.DateAndTime) = 2020) as R 
-- WHERE R.VALPERMIN > 0 
GROUP BY R.TagName, R.monthnum;