create function udsvf_total(@fromDate as datetime,@toDate as datetime,@equipment as varchar(max))
returns float
as
begin
declare @total as float
select @total=sum([Diff_Val]) from
(select DateAndTime,
	TagIndex,
	Val,
	coalesce(lead(Val) over (order by DateAndTime),0) as [Lead_Val],
	coalesce(lead(Val) over (order by DateAndTime)-Val,0) as [Diff_Val]
from [dbo].[FloatTable_test]
where DateAndTime between @fromDate and @toDate
and TagIndex in (select TagIndex from [dbo].[TagTable] where TagName like concat('%',@equipment,'\Energy')) and Val>0) as t1
where [Lead_Val]>0

return @total
end