DECLARE @timetable AS TABLE (fromdate datetime, todate datetime);
DECLARE @equipment AS NVARCHAR(MAX) = 'AdminOffice_and_Lab';
DECLARE @fdate AS datetime = '2020-12-29 15:00:00';
DECLARE @tdate AS datetime = '2020-12-29 16:00:00';

DECLARE @temp AS datetime;
SET @temp = @fdate;

WHILE @temp < @tdate
BEGIN
    INSERT INTO @timetable(fromdate, todate)
    VALUES (@temp, DATEADD(MINUTE, 15, @temp));
    SET @temp = DATEADD(MINUTE, 15, @temp);
END

SELECT
    t1.fromdate,
    t1.todate,
    COALESCE(dbo.udsvf_total(t1.fromdate, t1.todate, @equipment), 0) AS [Energy]
FROM @timetable AS t1;