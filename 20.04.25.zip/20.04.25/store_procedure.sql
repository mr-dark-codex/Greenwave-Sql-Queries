
--- DESCRIPTION OF STORE PROCEDURE ---

CREATE PROCEDURE UDSP_CHECK_PARAMTER(@givenDateAndTime datetime, @cw int)
AS 
BEGIN 

SELECT *
FROM
(
	SELECT dateandtime, parameterName, val , CWNO
	FROM
	(
		SELECT TOP(1) F.VAL, 
		SUBSTRING(T.TAGNAME, 0, CHARINDEX('\', T.tagName)) [CWNO],
		SUBSTRING(T.TagName, CHARINDEX('\', T.TagName) + 1, LEN(T.tagName)) [ParameterName], 
		F.DateAndTime
		From dbo.FloatTable_15min f, dbo.TagTable_15min t
		where t.TagIndex = f.tagindex
		and f.dateandtime BETWEEN DATEADD(MINUTE, -1440, @givenDateAndTime) AND  @givenDateAndTime
		and t.TagName LIKE CONCAT('%', @CW, '%HIGH_VALUE')
		ORDER BY F.DateAndTime DESC
	) AS HIGH_VALUE 
	union all
	SELECT dateandtime, parameterName, val , CWNO
	from
	(
		SELECT TOP(1) F.VAL,
		SUBSTRING(T.TAGNAME, 0, CHARINDEX('\', T.tagName)) [CWNO],
		SUBSTRING(T.TagName, CHARINDEX('\', T.TagName) + 1, LEN(T.tagName)) [ParameterName], 
		F.DateAndTime
		From dbo.FloatTable_15min f, dbo.TagTable_15min t
		where t.TagIndex = f.tagindex
		and f.dateandtime BETWEEN DATEADD(MINUTE, -1440, @givenDateAndTime) AND  @givenDateAndTime
		and t.TagName LIKE CONCAT('%', @CW, '%LOW_VALUE')
		ORDER BY F.DateAndTime DESC
	) AS LOW_VALUE
	union all
	SELECT dateandtime, parameterName, val , CWNO
	from
	(
		SELECT TOP(1) F.VAL, 
		SUBSTRING(T.TAGNAME, 0, CHARINDEX('\', T.tagName)) [CWNO],
		SUBSTRING(T.TagName, CHARINDEX('\', T.TagName) + 1, LEN(T.tagName)) [ParameterName], 
		F.DateAndTime
		From dbo.FloatTable_15min f, dbo.TagTable_15min t
		where t.TagIndex = f.tagindex
		and f.dateandtime BETWEEN DATEADD(MINUTE, -1440, @givenDateAndTime) AND  @givenDateAndTime
		and t.TagName LIKE CONCAT('%', @CW, '%TARGET_VALUE')
		ORDER BY F.DateAndTime DESC
	) AS TARGET_VALUE
) AS ALL_TABLE 
PIVOT (
	
	MAX(VAL) 
	FOR parameterName in (SKU_PKT_HIGH_VALUE, SKU_PKT_LOW_VALUE, SKU_PKT_target_VALUE)

) as PT
ORDER BY DateAndTime

END

